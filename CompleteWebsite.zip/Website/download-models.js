const https = require('https');
const fs = require('fs');
const path = require('path');

const modelsToDownload = [
    'ssd_mobilenetv1_model-weights_manifest.json',
    'ssd_mobilenetv1_model-shard1',
    'face_landmark_68_model-weights_manifest.json',
    'face_landmark_68_model-shard1',
    'face_recognition_model-weights_manifest.json',
    'face_recognition_model-shard1'
];

const baseUrl = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model/';
const modelsDir = './models';

// Create models directory if it doesn't exist
if (!fs.existsSync(modelsDir)) {
    fs.mkdirSync(modelsDir);
}

// Download function
function downloadFile(url, dest) {
    return new Promise((resolve, reject) => {
        const file = fs.createWriteStream(dest);
        https.get(url, response => {
            response.pipe(file);
            file.on('finish', () => {
                file.close();
                console.log(`Downloaded: ${dest}`);
                resolve();
            });
        }).on('error', err => {
            fs.unlink(dest, () => {}); // Delete the file if there was an error
            reject(err);
        });
    });
}

// Download all models
async function downloadModels() {
    console.log('Starting model downloads...');
    for (const model of modelsToDownload) {
        const url = baseUrl + model;
        const dest = path.join(modelsDir, model);
        try {
            await downloadFile(url, dest);
        } catch (error) {
            console.error(`Error downloading ${model}:`, error);
        }
    }
    console.log('All downloads completed!');
}

downloadModels(); 