// Mobile menu toggle
document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    
    if (hamburger) {
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            hamburger.classList.toggle('active');
        });
    }

    // Hide scroll indicator when scrolling
    const scrollIndicator = document.querySelector('.scroll-indicator');
    if (scrollIndicator) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 100) {
                scrollIndicator.style.opacity = '0';
            } else {
                scrollIndicator.style.opacity = '0.7';
            }
        });
    }

    // Animate elements on scroll
    const animateOnScroll = (elements) => {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate');
                }
            });
        }, { threshold: 0.1 });

        elements.forEach(element => observer.observe(element));
    };

    // Animate video containers
    const videoContainers = document.querySelectorAll('.video-container');
    if (videoContainers.length > 0) {
        animateOnScroll(videoContainers);
    }

    // Animate team members
    const teamMembers = document.querySelectorAll('.team-member');
    if (teamMembers.length > 0) {
        animateOnScroll(teamMembers);
    }

    // Password visibility toggle
    const passwordToggles = document.querySelectorAll('.password-toggle');
    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const passwordInput = this.previousElementSibling;
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    });

    // Signup form handling
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = {
                name: document.getElementById('name').value,
                email: document.getElementById('email').value,
                password: document.getElementById('password').value,
                confirmPassword: document.getElementById('confirmPassword').value
            };

            if (formData.password !== formData.confirmPassword) {
                alert('Passwords do not match!');
                return;
            }

            // Store user data (in real app, this would be sent to a server)
            localStorage.setItem('userData', JSON.stringify(formData));
            alert('Account created successfully!');
            window.location.href = 'login.html';
        });
    }

    // Login form handling
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = {
                name: document.getElementById('name').value,
                email: document.getElementById('email').value,
                password: document.getElementById('password').value
            };

            // Check credentials (in real app, this would be verified with a server)
            const storedData = JSON.parse(localStorage.getItem('userData') || '{}');
            
            if (storedData.email === formData.email && 
                storedData.password === formData.password &&
                storedData.name === formData.name) {
                // Set session
                localStorage.setItem('isLoggedIn', 'true');
                window.location.href = 'mainpage.html';
            } else {
                alert('Invalid credentials!');
            }
        });
    }

    // Logout handling
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            localStorage.removeItem('isLoggedIn');
            window.location.href = 'login.html';
        });
    }

    // Check authentication status
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const currentPage = window.location.pathname;
    
    if (currentPage.includes('mainpage.html') && !isLoggedIn) {
        window.location.href = 'login.html';
    }

    // Password strength meter
    const passwordInput = document.getElementById('password');
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            const strength = calculatePasswordStrength(this.value);
            updatePasswordStrength(strength);
        });
    }
});

// Helper functions
function showError(formGroup, message) {
    const error = document.createElement('div');
    error.className = 'error-message';
    error.style.color = '#ff4444';
    error.style.fontSize = '0.875rem';
    error.style.marginTop = '0.5rem';
    error.textContent = message;
    formGroup.appendChild(error);
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Modal functionality
const newPasswordBtn = document.querySelector('.new-btn');
const modal = document.getElementById('newPasswordModal');
const closeBtn = document.querySelector('.close-btn');
const cancelBtn = document.querySelector('.cancel-btn');
const togglePasswordBtn = document.querySelector('.toggle-password');
const passwordInput = document.getElementById('password');

// Open modal
newPasswordBtn.addEventListener('click', () => {
    modal.classList.add('active');
});

// Close modal functions
function closeModal() {
    modal.classList.remove('active');
    document.querySelector('.new-password-form').reset();
}

closeBtn.addEventListener('click', closeModal);
cancelBtn.addEventListener('click', closeModal);

// Close modal when clicking outside
modal.addEventListener('click', (e) => {
    if (e.target === modal) {
        closeModal();
    }
});

// Toggle password visibility
togglePasswordBtn.addEventListener('click', () => {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    togglePasswordBtn.querySelector('i').classList.toggle('fa-eye');
    togglePasswordBtn.querySelector('i').classList.toggle('fa-eye-slash');
});

// Handle form submission
document.querySelector('.new-password-form').addEventListener('submit', (e) => {
    e.preventDefault();
    
    const websiteName = document.getElementById('websiteName').value;
    const websiteUrl = document.getElementById('websiteUrl').value;
    const password = document.getElementById('password').value;

    // Here you would typically send this data to your backend
    console.log('New password entry:', { websiteName, websiteUrl, password });
    
    // Close the modal after submission
    closeModal();
});

// Right Menu Functionality
const rightMenu = document.querySelector('.right-menu');
const vaultSection = document.querySelector('.vault-section');
const favoritesBtn = document.querySelector('.favorites-btn');
const trashBtn = document.querySelector('.trash-btn');
const favoriteIcons = document.querySelectorAll('.favorite-btn');

// Toggle right menu
function toggleRightMenu() {
    rightMenu.classList.toggle('active');
    vaultSection.classList.toggle('right-menu-active');
}

// Handle menu item clicks
favoritesBtn.addEventListener('click', () => {
    favoritesBtn.classList.add('active');
    trashBtn.classList.remove('active');
    // Here you would typically filter to show only favorites
});

trashBtn.addEventListener('click', () => {
    trashBtn.classList.add('active');
    favoritesBtn.classList.remove('active');
    // Here you would typically filter to show only trash items
});

// Handle favorite icon clicks
favoriteIcons.forEach(icon => {
    icon.addEventListener('click', function() {
        this.classList.toggle('favorite-active');
        updateFavoriteCount();
    });
});

// Update favorite count
function updateFavoriteCount() {
    const activeFavorites = document.querySelectorAll('.favorite-btn.favorite-active').length;
    const countElement = favoritesBtn.querySelector('.count');
    countElement.textContent = activeFavorites;
}

// Initialize favorite count
updateFavoriteCount();

// Close right menu when clicking outside
document.addEventListener('click', (e) => {
    if (!rightMenu.contains(e.target) && !e.target.closest('.menu-toggle')) {
        rightMenu.classList.remove('active');
        vaultSection.classList.remove('right-menu-active');
    }
}); 

document.addEventListener('DOMContentLoaded', function () {
    loadPasswords(); // Load saved passwords when page loads

    // Handle form submission
    document.querySelector('.new-password-form').addEventListener('submit', function (e) {
        e.preventDefault();

        const websiteName = document.getElementById('websiteName').value.trim();
        const websiteUrl = document.getElementById('websiteUrl').value.trim();
        const password = document.getElementById('password').value.trim();

        if (!websiteName || !websiteUrl || !password) {
            alert("All fields are required!");
            return;
        }

        // Create new password entry
        const newPassword = {
            websiteName,
            websiteUrl,
            password
        };

        // Save to localStorage
        let passwords = JSON.parse(localStorage.getItem('passwords')) || [];
        passwords.push(newPassword);
        localStorage.setItem('passwords', JSON.stringify(passwords));

        // Refresh password list
        loadPasswords();

        // Clear form fields & close modal
        this.reset();
        closeModal();
    });
});

//Load Passwords
function loadPasswords() {
    const passwordList = document.querySelector('.password-list');
    passwordList.innerHTML = ''; // Clear the list

    let passwords = JSON.parse(localStorage.getItem('passwords')) || [];

    passwords.forEach((entry, index) => {
        passwordList.innerHTML += `
            <div class="password-item">
                <div class="password-info">
                    <div class="site-icon">
                        <i class="fas fa-globe"></i>
                    </div>
                    <div class="password-details">
                        <h3>${entry.websiteName}</h3>
                        <p>${entry.websiteUrl}</p>
                        <p>
                            <strong>Password:</strong> 
                            <span class="hidden-password" id="password-${index}">****</span>
                        </p>
                    </div>
                </div>
                <div class="password-actions">
                    <button class="action-btn toggle-password" onclick="togglePassword(${index}, '${entry.password}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="action-btn copy-btn" onclick="copyPassword('${entry.password}')">
                        <i class="fas fa-copy"></i>
                    </button>
                    <button class="action-btn delete-btn" onclick="deletePassword(${index})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
    });
}

// Copy password to clipboard
function copyPassword(password) {
    navigator.clipboard.writeText(password).then(() => {
        alert("Password copied!");
    });
}

// Delete password
function deletePassword(index) {
    let passwords = JSON.parse(localStorage.getItem('passwords')) || [];
    passwords.splice(index, 1);
    localStorage.setItem('passwords', JSON.stringify(passwords));
    loadPasswords();
}

// Close modal
function closeModal() {
    document.getElementById('newPasswordModal').classList.remove('active');
}

function togglePassword(index, realPassword) {
    const passwordSpan = document.getElementById(`password-${index}`);
    const buttonIcon = document.querySelector(`.password-item:nth-child(${index + 1}) .toggle-password i`);

    if (passwordSpan.textContent === "****") {
        passwordSpan.textContent = realPassword; // Show password
        buttonIcon.classList.replace("fa-eye", "fa-eye-slash");
    } else {
        passwordSpan.textContent = "****"; // Hide password
        buttonIcon.classList.replace("fa-eye-slash", "fa-eye");
    }
}

// Password strength calculator
function calculatePasswordStrength(password) {
    let strength = 0;
    if (password.length >= 8) strength += 25;
    if (password.match(/[a-z]/)) strength += 25;
    if (password.match(/[A-Z]/)) strength += 25;
    if (password.match(/[0-9]/)) strength += 25;
    return strength;
}

// Update password strength indicator
function updatePasswordStrength(strength) {
    const strengthBar = document.querySelector('.strength-bar');
    if (strengthBar) {
        strengthBar.style.width = strength + '%';
        if (strength < 50) {
            strengthBar.style.backgroundColor = '#ff4444';
        } else if (strength < 75) {
            strengthBar.style.backgroundColor = '#ffbb33';
        } else {
            strengthBar.style.backgroundColor = '#00C851';
        }
    }
}

