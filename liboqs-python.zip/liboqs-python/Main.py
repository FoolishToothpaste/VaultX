import oqs
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os
import hashlib
import json
import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                            QHBoxLayout, QPushButton, QLineEdit, QLabel, 
                            QStackedWidget, QTableWidget, QTableWidgetItem, 
                            QHeaderView, QDialog, QMessageBox, QFrame, QMenu)
from PyQt6.QtCore import Qt, QSize, QTimer
from PyQt6.QtGui import QFont, QIcon, QColor, QPalette, QAction
import random
import string
from datetime import datetime

# -----------------------
# Master Password Functions
# -----------------------

MASTER_FILE = "master.json"

def hash_master_password(password: str) -> str:
    """Hash the master password using SHA-256."""
    return hashlib.sha256(password.encode()).hexdigest()

def setup_master_password():
    """Set up a master password if one does not exist."""
    print("No master password set. Please create one.")
    while True:
        pw1 = input("Enter new master password: ").strip()
        pw2 = input("Confirm master password: ").strip()
        if pw1 == pw2 and pw1:
            master_hash = hash_master_password(pw1)
            with open(MASTER_FILE, "w") as f:
                json.dump({"master": master_hash}, f)
            print("Master password set successfully.\n")
            break
        else:
            print("Passwords do not match or are empty. Try again.")

def verify_master_password() -> bool:
    """Verify the entered master password against the stored hash."""
    if not os.path.exists(MASTER_FILE):
        setup_master_password()
    with open(MASTER_FILE, "r") as f:
        data = json.load(f)
        stored_hash = data.get("master")
    for _ in range(3):
        pw = input("Enter master password: ").strip()
        if hash_master_password(pw) == stored_hash:
            print("Master password verified.\n")
            return True
        else:
            print("Incorrect master password.")
    return False

# -----------------------
# Utility Functions for Encryption
# -----------------------

def derive_key(shared_secret: bytes) -> bytes:
    """
    Derive a 256-bit AES key from the shared secret using SHA-256.
    """
    return hashlib.sha256(shared_secret).digest()

def encrypt_data(plaintext: str, key: bytes) -> (bytes, bytes):
    """
    Encrypt the plaintext using AES-GCM.
    Returns a tuple (nonce, ciphertext).
    """
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)  # Standard nonce size for AES-GCM
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode(), None)
    return nonce, ciphertext

def decrypt_data(nonce: bytes, ciphertext: bytes, key: bytes) -> str:
    """
    Decrypt the ciphertext using AES-GCM.
    """
    aesgcm = AESGCM(key)
    plaintext = aesgcm.decrypt(nonce, ciphertext, None)
    return plaintext.decode()

# -----------------------
# OQS KEM Class
# -----------------------

class OQSKEM:
    """
    Wraps the OQS Key Encapsulation mechanism using Kyber512.
    A persistent receiver key pair is generated upon instantiation.
    """
    def __init__(self, alg="Kyber512"):
        self.alg = alg
        self.receiver = oqs.KeyEncapsulation(self.alg)
        self.public_key = self.receiver.generate_keypair()
        print("Receiver key pair generated using", self.alg)

    def encapsulate(self) -> (bytes, bytes):
        """
        Sender-side: encapsulate a shared secret using the receiver's public key.
        Returns a tuple (encapsulated key ct, shared secret).
        """
        with oqs.KeyEncapsulation(self.alg) as sender:
            ct, shared_secret = sender.encap_secret(self.public_key)
        return ct, shared_secret

    def decapsulate(self, ct: bytes) -> bytes:
        """
        Receiver-side: decapsulate to recover the shared secret.
        """
        return self.receiver.decap_secret(ct)

# -----------------------
# Password Encryption Helpers
# -----------------------

def encrypt_password(password: str, kem: OQSKEM) -> dict:
    """
    Encrypts the password:
      - Encapsulate a shared secret using OQS.
      - Derive an AES key from the shared secret.
      - Encrypt the password using AES-GCM.
    Returns a dict with hex-encoded nonce, ciphertext, and encapsulated key (ct).
    """
    ct, shared_secret = kem.encapsulate()
    sym_key = derive_key(shared_secret)
    nonce, ciphertext = encrypt_data(password, sym_key)
    return {
        "nonce": nonce.hex(),
        "ciphertext": ciphertext.hex(),
        "ct": ct.hex()
    }

def decrypt_password(enc_data: dict, kem: OQSKEM) -> str:
    """
    Decrypts the password record using stored nonce, ciphertext, and ct.
    """
    nonce = bytes.fromhex(enc_data["nonce"])
    ciphertext = bytes.fromhex(enc_data["ciphertext"])
    ct = bytes.fromhex(enc_data["ct"])
    shared_secret = kem.decapsulate(ct)
    sym_key = derive_key(shared_secret)
    return decrypt_data(nonce, ciphertext, sym_key)

# -----------------------
# Password Manager Class
# -----------------------

class PasswordManager:
    def __init__(self, filename: str, kem: OQSKEM):
        self.filename = filename
        self.kem = kem
        # Records are stored as a dictionary with website as the key.
        self.records = {}
        self.load_records()

    def load_records(self):
        """Load records from a JSON file. If the file contains a list, convert it to a dictionary."""
        if os.path.exists(self.filename):
            with open(self.filename, "r") as f:
                data = json.load(f)
            # If data is a list, convert it to dict keyed by website (lowercase).
            if isinstance(data, list):
                self.records = {}
                for rec in data:
                    website = rec.get("website", "").strip().lower()
                    if website:
                        self.records[website] = rec
                print("Converted existing list of records to dictionary format.")
            else:
                self.records = data
            print(f"Loaded {len(self.records)} record(s) from {self.filename}")
        else:
            self.records = {}
            print("No existing password file found. Starting fresh.")

    def save_records(self):
        """Save records to a JSON file."""
        with open(self.filename, "w") as f:
            json.dump(self.records, f, indent=4)
        print("Records saved.")

    def add_record(self):
        """
        Prompt for website, username, and password.
        Uses the website name as the unique key.
        If username is left empty, the website name is used as username.
        """
        website = input("Enter website (or account name): ").strip().lower()
        if website in self.records:
            print("A record for this website already exists. Use modify to update it.")
            return
        username = input("Enter username (leave blank to use website): ").strip()
        if not username:
            username = website
        password = input("Enter password: ").strip()
        enc_data = encrypt_password(password, self.kem)
        # Also store the website inside the record for reference.
        self.records[website] = {
            "website": website,
            "username": username,
            "enc_data": enc_data
        }
        self.save_records()
        print("Record added.")

    def list_records(self):
        """List all stored records by website and username."""
        if not self.records:
            print("No records available.")
            return
        print("\nStored Records:")
        for website, rec in self.records.items():
            print(f"Website: {website} | Username: {rec['username']}")

    def view_record(self):
        """
        View (decrypt and display) a record by website name.
        """
        website = input("Enter website to view: ").strip().lower()
        record = self.records.get(website)
        if not record:
            print("Record not found.")
            return
        try:
            decrypted = decrypt_password(record["enc_data"], self.kem)
            print(f"\nWebsite: {website}")
            print(f"Username: {record['username']}")
            print(f"Password: {decrypted}")
        except Exception as e:
            print("Decryption failed:", e)

    def delete_record(self):
        """
        Delete a record by website name.
        """
        website = input("Enter website to delete: ").strip().lower()
        if website in self.records:
            del self.records[website]
            self.save_records()
            print("Record deleted.")
        else:
            print("Record not found.")

    def modify_record(self):
        """
        Modify an existing record.
        The user can update the username and/or password.
        """
        website = input("Enter website to modify: ").strip().lower()
        record = self.records.get(website)
        if not record:
            print("Record not found.")
            return
        print("Leave a field blank to keep the current value.")
        new_username = input(f"Enter new username (current: {record['username']}): ").strip()
        new_password = input("Enter new password (if updating): ").strip()
        if new_username:
            record["username"] = new_username
        if new_password:
            record["enc_data"] = encrypt_password(new_password, self.kem)
        self.records[website] = record
        self.save_records()
        print("Record updated.")

# -----------------------
# Main Menu Interface
# -----------------------

def main_menu():
    if not verify_master_password():
        print("Master password verification failed. Exiting...")
        return

    # Initialize the OQS KEM instance with Kyber512.
    kem_instance = OQSKEM("Kyber512")
    # Initialize the Password Manager with a JSON file.
    pm = PasswordManager("passwords.json", kem_instance)

    while True:
        print("\nPassword Manager Menu:")
        print("1. Add a new record")
        print("2. List all records")
        print("3. View a record")
        print("4. Modify a record")
        print("5. Delete a record")
        print("6. Exit")
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            pm.add_record()
        elif choice == "2":
            pm.list_records()
        elif choice == "3":
            pm.view_record()
        elif choice == "4":
            pm.modify_record()
        elif choice == "5":
            pm.delete_record()
        elif choice == "6":
            print("Exiting...")
            break
        else:
            print("Invalid option. Please try again.")

# Modern Color Scheme
COLORS = {
    'background': '#1a1a1a',
    'secondary_bg': '#2d2d2d',
    'accent': '#007AFF',
    'accent_hover': '#0056b3',
    'text': '#ffffff',
    'text_secondary': '#b3b3b3',
    'success': '#28a745',
    'error': '#dc3545',
    'warning': '#ffc107',
    'border': '#404040'
}

class StyledLineEdit(QLineEdit):
    def __init__(self, placeholder=""):
        super().__init__()
        self.setPlaceholderText(placeholder)
        self.setStyleSheet(f"""
            QLineEdit {{
                background-color: {COLORS['secondary_bg']};
                color: {COLORS['text']};
                border: 1px solid {COLORS['border']};
                padding: 10px;
                border-radius: 5px;
                font-size: 14px;
            }}
            QLineEdit:focus {{
                border: 1px solid {COLORS['accent']};
            }}
        """)

class StyledButton(QPushButton):
    def __init__(self, text, accent=False):
        super().__init__(text)
        color = COLORS['accent'] if accent else COLORS['secondary_bg']
        hover_color = COLORS['accent_hover'] if accent else '#3d3d3d'
        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {color};
                color: {COLORS['text']};
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
            }}
            QPushButton:hover {{
                background-color: {hover_color};
            }}
        """)

class PasswordDialog(QDialog):
    def __init__(self, parent=None, edit_mode=False, existing_data=None):
        super().__init__(parent)
        self.setWindowTitle("Edit Password" if edit_mode else "Add Password")
        self.edit_mode = edit_mode
        self.existing_data = existing_data
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        self.setStyleSheet(f"background-color: {COLORS['background']};")

        # Website field
        layout.addWidget(QLabel("Website", styleSheet=f"color: {COLORS['text']};"))
        self.website_input = StyledLineEdit("Enter website name")
        if self.edit_mode:
            self.website_input.setText(self.existing_data['website'])
            self.website_input.setEnabled(False)
        layout.addWidget(self.website_input)

        # Username field
        layout.addWidget(QLabel("Username", styleSheet=f"color: {COLORS['text']};"))
        self.username_input = StyledLineEdit("Enter username")
        if self.edit_mode:
            self.username_input.setText(self.existing_data['username'])
        layout.addWidget(self.username_input)

        # Password field
        layout.addWidget(QLabel("Password", styleSheet=f"color: {COLORS['text']};"))
        password_layout = QHBoxLayout()
        self.password_input = StyledLineEdit("Enter password")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        password_layout.addWidget(self.password_input)

        self.toggle_btn = StyledButton("Show")
        self.toggle_btn.clicked.connect(self.toggle_password)
        password_layout.addWidget(self.toggle_btn)
        layout.addLayout(password_layout)

        # Buttons
        button_layout = QHBoxLayout()
        save_btn = StyledButton("Save", accent=True)
        save_btn.clicked.connect(self.accept)
        cancel_btn = StyledButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(save_btn)
        button_layout.addWidget(cancel_btn)
        layout.addLayout(button_layout)

    def toggle_password(self):
        if self.password_input.echoMode() == QLineEdit.EchoMode.Password:
            self.password_input.setEchoMode(QLineEdit.EchoMode.Normal)
            self.toggle_btn.setText("Hide")
        else:
            self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
            self.toggle_btn.setText("Show")

    def get_values(self):
        return {
            'website': self.website_input.text().strip().lower(),
            'username': self.username_input.text().strip(),
            'password': self.password_input.text()
        }

class PasswordDetailsDialog(QDialog):
    def __init__(self, parent=None, record=None, kem=None):
        super().__init__(parent)
        self.record = record
        self.kem = kem
        self.decrypted_password = None
        self.setWindowTitle("Password Details")
        self.setMinimumWidth(400)
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(20)

        # Create main container
        container = QFrame()
        container.setStyleSheet("""
            QFrame {
                background-color: #2b2b2b;
                border-radius: 10px;
                padding: 20px;
            }
        """)
        container_layout = QVBoxLayout(container)

        # Website info
        website_group = self.create_info_group("Website", self.record['website'])
        container_layout.addWidget(website_group)
        container_layout.addSpacing(10)

        # Username info
        username_group = self.create_info_group("Username", self.record['username'])
        container_layout.addWidget(username_group)
        container_layout.addSpacing(10)

        # Password section
        password_label = QLabel("Password")
        password_label.setStyleSheet("color: #aaaaaa; font-size: 12px;")
        container_layout.addWidget(password_label)

        # Password display layout
        password_layout = QHBoxLayout()
        
        self.password_field = QLineEdit()
        self.password_field.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_field.setReadOnly(True)
        self.password_field.setStyleSheet("""
            QLineEdit {
                background-color: #363636;
                border: 1px solid #404040;
                border-radius: 5px;
                padding: 8px;
                color: white;
            }
        """)
        
        # Decrypt and set password
        try:
            self.decrypted_password = decrypt_password(self.record['enc_data'], self.kem)
            self.password_field.setText(self.decrypted_password)
        except Exception as e:
            self.password_field.setText("Failed to decrypt")
            print(f"Decryption error: {str(e)}")  # For debugging

        # Buttons
        self.toggle_btn = QPushButton("Show")
        self.toggle_btn.setStyleSheet("""
            QPushButton {
                background-color: #404040;
                color: white;
                border: none;
                padding: 8px 15px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #4a4a4a;
            }
        """)
        self.toggle_btn.clicked.connect(self.toggle_password)
        
        copy_btn = QPushButton("Copy")
        copy_btn.setStyleSheet("""
            QPushButton {
                background-color: #404040;
                color: white;
                border: none;
                padding: 8px 15px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #4a4a4a;
            }
        """)
        copy_btn.clicked.connect(self.copy_password)
        
        password_layout.addWidget(self.password_field)
        password_layout.addWidget(self.toggle_btn)
        password_layout.addWidget(copy_btn)
        
        container_layout.addLayout(password_layout)
        layout.addWidget(container)

        # Action buttons
        button_layout = QHBoxLayout()
        
        edit_btn = QPushButton("Edit")
        edit_btn.setStyleSheet("""
            QPushButton {
                background-color: #0d6efd;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #0b5ed7;
            }
        """)
        edit_btn.clicked.connect(self.edit_password)
        button_layout.addWidget(edit_btn)
        
        delete_btn = QPushButton("Delete")
        delete_btn.setStyleSheet("""
            QPushButton {
                background-color: #dc3545;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #bb2d3b;
            }
        """)
        delete_btn.clicked.connect(self.delete_password)
        button_layout.addWidget(delete_btn)
        
        layout.addLayout(button_layout)

    def create_info_group(self, label_text, value_text):
        group = QFrame()
        layout = QVBoxLayout(group)
        
        label = QLabel(label_text)
        label.setStyleSheet("color: #aaaaaa; font-size: 12px;")
        layout.addWidget(label)
        
        value = QLabel(value_text)
        value.setStyleSheet("color: white; font-size: 14px; font-weight: bold;")
        layout.addWidget(value)
        
        return group

    def toggle_password(self):
        if self.password_field.echoMode() == QLineEdit.EchoMode.Password:
            self.password_field.setEchoMode(QLineEdit.EchoMode.Normal)
            self.toggle_btn.setText("Hide")
        else:
            self.password_field.setEchoMode(QLineEdit.EchoMode.Password)
            self.toggle_btn.setText("Show")

    def copy_password(self):
        if self.decrypted_password:
            QApplication.clipboard().setText(self.decrypted_password)
            QMessageBox.information(self, "Success", "Password copied to clipboard!")

    def edit_password(self):
        self.parent().show_edit_dialog(self.record)
        self.accept()

    def delete_password(self):
        reply = QMessageBox.question(
            self,
            'Confirm Delete',
            f'Are you sure you want to delete the password for {self.record["website"]}?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            self.parent().delete_password(self.record['website'])
            self.accept()

class QuantumPasswordManager(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Quantum-Safe Password Manager")
        self.setMinimumSize(1000, 700)
        self.setStyleSheet(f"background-color: {COLORS['background']};")
        
        # Initialize crypto components
        self.kem = None
        self.password_manager = None
        
        self.setup_ui()
        self.show_login_screen()

    def setup_ui(self):
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)
        
        # Create stacked widget for different screens
        self.stacked_widget = QStackedWidget()
        self.layout.addWidget(self.stacked_widget)
        
        # Create different screens
        self.create_login_screen()
        self.create_main_screen()

    def show_login_screen(self):
        """Switch to the login screen"""
        self.stacked_widget.setCurrentIndex(0)
        if hasattr(self, 'master_password'):
            self.master_password.clear()

    def create_login_screen(self):
        login_widget = QWidget()
        login_layout = QVBoxLayout(login_widget)
        login_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Title
        title = QLabel("🔐 Quantum-Safe Password Manager")
        title.setFont(QFont("Arial", 20, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {COLORS['text']};")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        login_layout.addWidget(title)

        # Password input
        self.master_password = StyledLineEdit("Enter Master Password")
        self.master_password.setEchoMode(QLineEdit.EchoMode.Password)
        login_layout.addWidget(self.master_password)

        # Login button
        login_btn = StyledButton("Login", accent=True)
        login_btn.clicked.connect(self.verify_master_password)
        login_layout.addWidget(login_btn)

        # Setup button
        setup_btn = StyledButton("First Time Setup")
        setup_btn.clicked.connect(self.show_setup_dialog)
        login_layout.addWidget(setup_btn)

        self.stacked_widget.addWidget(login_widget)

    def create_main_screen(self):
        main_widget = QWidget()
        main_layout = QVBoxLayout(main_widget)

        # Search and Add button bar
        top_bar = QHBoxLayout()
        self.search_input = StyledLineEdit("Search passwords...")
        self.search_input.textChanged.connect(self.filter_passwords)
        top_bar.addWidget(self.search_input)

        add_btn = StyledButton("Add Password", accent=True)
        add_btn.clicked.connect(self.show_add_dialog)
        top_bar.addWidget(add_btn)
        main_layout.addLayout(top_bar)

        # Password table
        self.password_table = QTableWidget()
        self.password_table.setColumnCount(3)
        self.password_table.setHorizontalHeaderLabels(["Website", "Username", "Last Modified"])
        self.password_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.password_table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {COLORS['secondary_bg']};
                color: {COLORS['text']};
                border: none;
                border-radius: 10px;
                gridline-color: {COLORS['border']};
            }}
            QHeaderView::section {{
                background-color: {COLORS['secondary_bg']};
                color: {COLORS['text']};
                padding: 12px;
                border: none;
            }}
            QTableWidget::item {{
                padding: 10px;
            }}
            QTableWidget::item:selected {{
                background-color: {COLORS['accent']};
            }}
        """)

        # Enable context menu and double-click
        self.password_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.password_table.customContextMenuRequested.connect(self.show_context_menu)
        self.password_table.doubleClicked.connect(self.show_password_details)

        main_layout.addWidget(self.password_table)
        self.stacked_widget.addWidget(main_widget)

    def show_setup_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Setup Master Password")
        dialog.setStyleSheet(f"background-color: {COLORS['background']};")
        layout = QVBoxLayout(dialog)

        layout.addWidget(QLabel("Create Master Password", styleSheet=f"color: {COLORS['text']};"))
        password = StyledLineEdit()
        password.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(password)

        layout.addWidget(QLabel("Confirm Password", styleSheet=f"color: {COLORS['text']};"))
        confirm = StyledLineEdit()
        confirm.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(confirm)

        create_btn = StyledButton("Create Password", accent=True)
        layout.addWidget(create_btn)

        def create_master():
            if password.text() != confirm.text():
                self.show_error("Passwords do not match!")
                return
            if not password.text():
                self.show_error("Password cannot be empty!")
                return

            try:
                with open("master.json", "w") as f:
                    json.dump({"master": hash_master_password(password.text())}, f)
                dialog.accept()
                self.show_success("Master password created!")
            except Exception as e:
                self.show_error(f"Setup failed: {str(e)}")

        create_btn.clicked.connect(create_master)
        dialog.exec()

    def show_context_menu(self, position):
        menu = QMenu(self)
        menu.setStyleSheet(f"""
            QMenu {{
                background-color: {COLORS['secondary_bg']};
                color: {COLORS['text']};
                border: 1px solid {COLORS['border']};
            }}
            QMenu::item:selected {{
                background-color: {COLORS['accent']};
            }}
        """)

        view_action = menu.addAction("View")
        edit_action = menu.addAction("Edit")
        delete_action = menu.addAction("Delete")

        action = menu.exec(self.password_table.viewport().mapToGlobal(position))
        if not action:
            return

        row = self.password_table.indexAt(position).row()
        if row >= 0:
            website = self.password_table.item(row, 0).text()
            record = self.password_manager.records.get(website)

            if action == view_action:
                self.show_password_details(self.password_table.indexAt(position))
            elif action == edit_action:
                self.show_edit_dialog(record)
            elif action == delete_action:
                self.delete_password(website)

    def show_password_details(self, index):
        try:
            website = self.password_table.item(index.row(), 0).text()
            record = self.password_manager.records.get(website)
            
            if record:
                dialog = PasswordDetailsDialog(self, record, self.kem)
                dialog.exec()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error showing password details: {str(e)}")

    def show_edit_dialog(self, record):
        dialog = PasswordDialog(self, edit_mode=True, existing_data=record)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.update_password(dialog.get_values())

    def show_add_dialog(self):
        dialog = PasswordDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            values = dialog.get_values()
            try:
                website = values['website']
                if website in self.password_manager.records:
                    self.show_error("A record for this website already exists!")
                    return
                
                enc_data = encrypt_password(values['password'], self.kem)
                self.password_manager.records[website] = {
                    'website': website,
                    'username': values['username'],
                    'enc_data': enc_data,
                    'last_modified': datetime.now().strftime("%Y-%m-%d %H:%M")
                }
                self.password_manager.save_records()
                self.load_passwords()
                self.show_success("Password added successfully!")
            except Exception as e:
                self.show_error(f"Failed to add password: {str(e)}")

    def update_password(self, values):
        try:
            website = values['website']
            if website in self.password_manager.records:
                record = self.password_manager.records[website]
                record['username'] = values['username']
                if values['password']:
                    record['enc_data'] = encrypt_password(values['password'], self.kem)
                record['last_modified'] = datetime.now().strftime("%Y-%m-%d %H:%M")
                self.password_manager.save_records()
                self.load_passwords()
                self.show_success("Password updated successfully!")
        except Exception as e:
            self.show_error(f"Failed to update password: {str(e)}")

    def delete_password(self, website):
        reply = QMessageBox.question(
            self,
            'Confirm Delete',
            f'Are you sure you want to delete the password for {website}?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            try:
                del self.password_manager.records[website]
                self.password_manager.save_records()
                self.load_passwords()
                self.show_success("Password deleted successfully!")
            except Exception as e:
                self.show_error(f"Failed to delete password: {str(e)}")

    def load_passwords(self):
        self.password_table.setRowCount(0)
        for website, record in self.password_manager.records.items():
            row = self.password_table.rowCount()
            self.password_table.insertRow(row)
            self.password_table.setItem(row, 0, QTableWidgetItem(website))
            self.password_table.setItem(row, 1, QTableWidgetItem(record['username']))
            self.password_table.setItem(row, 2, QTableWidgetItem(
                record.get('last_modified', 'N/A')
            ))

    def filter_passwords(self):
        search_text = self.search_input.text().lower()
        for row in range(self.password_table.rowCount()):
            website = self.password_table.item(row, 0).text().lower()
            username = self.password_table.item(row, 1).text().lower()
            self.password_table.setRowHidden(
                row, 
                not (search_text in website or search_text in username)
            )

    def verify_master_password(self):
        password = self.master_password.text()
        if not password:
            self.show_error("Password cannot be empty!")
            return
            
        try:
            if not os.path.exists("master.json"):
                self.show_error("No master password set. Please use setup!")
                return
                
            with open("master.json", "r") as f:
                stored = json.load(f)
                if stored["master"] == hash_master_password(password):
                    self.initialize_crypto()
                    self.show_main_screen()
                else:
                    self.show_error("Incorrect password!")
        except Exception as e:
            self.show_error(f"Verification failed: {str(e)}")

    def initialize_crypto(self):
        self.kem = OQSKEM("Kyber512")
        self.password_manager = PasswordManager("passwords.json", self.kem)

    def show_main_screen(self):
        self.stacked_widget.setCurrentIndex(1)
        self.load_passwords()

    def show_success(self, message):
        QMessageBox.information(self, "Success", message)

    def show_error(self, message):
        QMessageBox.critical(self, "Error", message)

def main():
    app = QApplication(sys.argv)
    window = QuantumPasswordManager()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
