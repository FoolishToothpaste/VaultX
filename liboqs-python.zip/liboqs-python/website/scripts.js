document.addEventListener("DOMContentLoaded", function () {
  // --- Other functionality remains unchanged ---

  // Mobile menu toggle, scroll indicator, animations, modal, etc.
  // (Keep your existing code here.)

  // ------------- Updated Authentication Form Functionality -------------

  // Signup Form Submission using fetch to /signup endpoint
  const signupForm = document.querySelector(".signup-form");
  if (signupForm) {
    signupForm.addEventListener("submit", function (e) {
      e.preventDefault();

      // Retrieve form field values
      // (Name is optional for backend if not used; backend currently uses email and password.)
      const name = document.getElementById("signup-name").value.trim();
      const email = document.getElementById("signup-email").value.trim();
      const password = document.getElementById("signup-password").value;
      const confirmPassword = document.getElementById(
        "signup-confirm-password"
      ).value;

      // Basic validation
      if (!email || !password || !confirmPassword) {
        alert("Email and password fields are required!");
        return;
      }
      if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return;
      }

      // Send POST request to /signup endpoint using URL-encoded form data
      fetch("/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          email: email,
          password: password,
        }),
      })
        .then((response) => {
          if (!response.ok) {
            return response.json().then((data) => {
              throw new Error(data.detail || "Signup failed");
            });
          }
          return response.json();
        })
        .then((data) => {
          alert("Account created successfully!");
          window.location.href = "login.html"; // Redirect to login page
        })
        .catch((error) => {
          alert("Error: " + error.message);
        });
    });
  }

  // Login Form Submission using fetch to /login endpoint
  const loginForm = document.querySelector(".login-form");
  if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault();

      // For login, only email and password are required (name field is ignored)
      const email = document.getElementById("login-email").value.trim();
      const password = document.getElementById("login-password").value;

      if (!email || !password) {
        alert("Email and password are required!");
        return;
      }

      // Send POST request to /login endpoint
      fetch("/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          email: email,
          password: password,
        }),
      })
        .then((response) => {
          if (!response.ok) {
            return response.json().then((data) => {
              throw new Error(data.detail || "Login failed");
            });
          }
          return response.json();
        })
        .then((data) => {
          alert("Login successful!");
          window.location.href = "mainpage.html"; // Redirect to main page after login
        })
        .catch((error) => {
          alert("Error: " + error.message);
        });
    });
  }

  // ------------- End of Updated Authentication Functionality -------------

  // --- Rest of your existing code for modal, right menu, localStorage-based password management, etc. ---

  // Example: Password modal submission and localStorage-based password management remain as-is.
  document.addEventListener("DOMContentLoaded", function () {
    loadPasswords(); // Load saved passwords when page loads

    // Handle new password form submission (still using localStorage for vault data)
    document
      .querySelector(".new-password-form")
      .addEventListener("submit", function (e) {
        e.preventDefault();

        const websiteName = document.getElementById("websiteName").value.trim();
        const websiteUrl = document.getElementById("websiteUrl").value.trim();
        const password = document.getElementById("password").value.trim();

        if (!websiteName || !websiteUrl || !password) {
          alert("All fields are required!");
          return;
        }

        // Create new password entry
        const newPassword = {
          websiteName,
          websiteUrl,
          password,
        };

        // Save to localStorage
        let passwords = JSON.parse(localStorage.getItem("passwords")) || [];
        passwords.push(newPassword);
        localStorage.setItem("passwords", JSON.stringify(passwords));

        // Refresh password list
        loadPasswords();

        // Clear form fields & close modal
        this.reset();
        closeModal();
      });
  });

  // ... (other functions: loadPasswords, copyPassword, deletePassword, modal toggle, etc.)
});
