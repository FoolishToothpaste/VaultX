// Mobile menu toggle
document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    if (hamburger) {
        hamburger.addEventListener('click', function() {
            document.querySelector('.nav-links').classList.toggle('active');
            this.classList.toggle('active');
        });
    }

    // Hide scroll indicator when scrolling
    const scrollIndicator = document.querySelector('.scroll-indicator');
    if (scrollIndicator) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 100) {
                scrollIndicator.style.opacity = '0';
            } else {
                scrollIndicator.style.opacity = '0.7';
            }
        });
    }

    // Animate elements on scroll
    const animateOnScroll = (elements) => {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate');
                }
            });
        }, { threshold: 0.1 });

        elements.forEach(element => observer.observe(element));
    };

    // Animate video containers
    const videoContainers = document.querySelectorAll('.video-container');
    if (videoContainers.length > 0) {
        animateOnScroll(videoContainers);
    }

    // Animate team members
    const teamMembers = document.querySelectorAll('.team-member');
    if (teamMembers.length > 0) {
        animateOnScroll(teamMembers);
    }

    // Authentication Form Functionality
    // Password visibility toggle
    const passwordToggles = document.querySelectorAll('.password-toggle');
    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const input = this.previousElementSibling;
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);
            
            // Toggle icon
            this.innerHTML = type === 'password' 
                ? '<i class="fas fa-eye"></i>' 
                : '<i class="fas fa-eye-slash"></i>';
        });
    });

    // Form validation
    const authForms = document.querySelectorAll('.auth-form');
    authForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            let isValid = true;
            const formData = new FormData(this);

            // Basic validation
            for (let [key, value] of formData.entries()) {
                const input = form.querySelector(`[name="${key}"]`);
                const formGroup = input.closest('.form-group');
                
                // Remove any existing error messages
                const existingError = formGroup.querySelector('.error-message');
                if (existingError) existingError.remove();

                // Validate empty fields
                if (!value.trim()) {
                    isValid = false;
                    showError(formGroup, 'This field is required');
                    continue;
                }

                // Email validation
                if (key === 'email' && !isValidEmail(value)) {
                    isValid = false;
                    showError(formGroup, 'Please enter a valid email address');
                }

                // Password validation
                if (key === 'password' && value.length < 8) {
                    isValid = false;
                    showError(formGroup, 'Password must be at least 8 characters long');
                }

                // Confirm password validation
                if (key === 'confirmPassword') {
                    const password = formData.get('password');
                    if (value !== password) {
                        isValid = false;
                        showError(formGroup, 'Passwords do not match');
                    }
                }
            }

            if (isValid) {
                // Add success animation
                const submitBtn = form.querySelector('.submit-btn');
                submitBtn.innerHTML = '<i class="fas fa-check"></i> Success!';
                submitBtn.style.backgroundColor = '#4CAF50';
                
                // Reset form after delay
                setTimeout(() => {
                    form.reset();
                    submitBtn.innerHTML = form.classList.contains('login-form') 
                        ? '<i class="fas fa-sign-in-alt"></i> Login' 
                        : '<i class="fas fa-user-plus"></i> Sign Up';
                    submitBtn.style.backgroundColor = '';
                }, 2000);
            }
        });
    });
});

// Helper functions
function showError(formGroup, message) {
    const error = document.createElement('div');
    error.className = 'error-message';
    error.style.color = '#ff4444';
    error.style.fontSize = '0.875rem';
    error.style.marginTop = '0.5rem';
    error.textContent = message;
    formGroup.appendChild(error);
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Modal functionality
const newPasswordBtn = document.querySelector('.new-btn');
const modal = document.getElementById('newPasswordModal');
const closeBtn = document.querySelector('.close-btn');
const cancelBtn = document.querySelector('.cancel-btn');
const togglePasswordBtn = document.querySelector('.toggle-password');
const passwordInput = document.getElementById('password');

// Open modal
newPasswordBtn.addEventListener('click', () => {
    modal.classList.add('active');
});

// Close modal functions
function closeModal() {
    modal.classList.remove('active');
    document.querySelector('.new-password-form').reset();
}

closeBtn.addEventListener('click', closeModal);
cancelBtn.addEventListener('click', closeModal);

// Close modal when clicking outside
modal.addEventListener('click', (e) => {
    if (e.target === modal) {
        closeModal();
    }
});

// Toggle password visibility
togglePasswordBtn.addEventListener('click', () => {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    togglePasswordBtn.querySelector('i').classList.toggle('fa-eye');
    togglePasswordBtn.querySelector('i').classList.toggle('fa-eye-slash');
});

// Handle form submission
document.querySelector('.new-password-form').addEventListener('submit', (e) => {
    e.preventDefault();
    
    const websiteName = document.getElementById('websiteName').value;
    const websiteUrl = document.getElementById('websiteUrl').value;
    const password = document.getElementById('password').value;

    // Here you would typically send this data to your backend
    console.log('New password entry:', { websiteName, websiteUrl, password });
    
    // Close the modal after submission
    closeModal();
});

// Right Menu Functionality
const rightMenu = document.querySelector('.right-menu');
const vaultSection = document.querySelector('.vault-section');
const favoritesBtn = document.querySelector('.favorites-btn');
const trashBtn = document.querySelector('.trash-btn');
const favoriteIcons = document.querySelectorAll('.favorite-btn');

// Toggle right menu
function toggleRightMenu() {
    rightMenu.classList.toggle('active');
    vaultSection.classList.toggle('right-menu-active');
}

// Handle menu item clicks
favoritesBtn.addEventListener('click', () => {
    favoritesBtn.classList.add('active');
    trashBtn.classList.remove('active');
    // Here you would typically filter to show only favorites
});

trashBtn.addEventListener('click', () => {
    trashBtn.classList.add('active');
    favoritesBtn.classList.remove('active');
    // Here you would typically filter to show only trash items
});

// Handle favorite icon clicks
favoriteIcons.forEach(icon => {
    icon.addEventListener('click', function() {
        this.classList.toggle('favorite-active');
        updateFavoriteCount();
    });
});

// Update favorite count
function updateFavoriteCount() {
    const activeFavorites = document.querySelectorAll('.favorite-btn.favorite-active').length;
    const countElement = favoritesBtn.querySelector('.count');
    countElement.textContent = activeFavorites;
}

// Initialize favorite count
updateFavoriteCount();

// Close right menu when clicking outside
document.addEventListener('click', (e) => {
    if (!rightMenu.contains(e.target) && !e.target.closest('.menu-toggle')) {
        rightMenu.classList.remove('active');
        vaultSection.classList.remove('right-menu-active');
    }
}); 

document.addEventListener('DOMContentLoaded', function () {
    loadPasswords(); // Load saved passwords when page loads

    // Handle form submission
    document.querySelector('.new-password-form').addEventListener('submit', function (e) {
        e.preventDefault();

        const websiteName = document.getElementById('websiteName').value.trim();
        const websiteUrl = document.getElementById('websiteUrl').value.trim();
        const password = document.getElementById('password').value.trim();

        if (!websiteName || !websiteUrl || !password) {
            alert("All fields are required!");
            return;
        }

        // Create new password entry
        const newPassword = {
            websiteName,
            websiteUrl,
            password
        };

        // Save to localStorage
        let passwords = JSON.parse(localStorage.getItem('passwords')) || [];
        passwords.push(newPassword);
        localStorage.setItem('passwords', JSON.stringify(passwords));

        // Refresh password list
        loadPasswords();

        // Clear form fields & close modal
        this.reset();
        closeModal();
    });
});

//Load Passwords
function loadPasswords() {
    const passwordList = document.querySelector('.password-list');
    passwordList.innerHTML = ''; // Clear the list

    let passwords = JSON.parse(localStorage.getItem('passwords')) || [];

    passwords.forEach((entry, index) => {
        passwordList.innerHTML += `
            <div class="password-item">
                <div class="password-info">
                    <div class="site-icon">
                        <i class="fas fa-globe"></i>
                    </div>
                    <div class="password-details">
                        <h3>${entry.websiteName}</h3>
                        <p>${entry.websiteUrl}</p>
                        <p>
                            <strong>Password:</strong> 
                            <span class="hidden-password" id="password-${index}">****</span>
                        </p>
                    </div>
                </div>
                <div class="password-actions">
                    <button class="action-btn toggle-password" onclick="togglePassword(${index}, '${entry.password}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="action-btn copy-btn" onclick="copyPassword('${entry.password}')">
                        <i class="fas fa-copy"></i>
                    </button>
                    <button class="action-btn delete-btn" onclick="deletePassword(${index})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
    });
}



// Copy password to clipboard
function copyPassword(password) {
    navigator.clipboard.writeText(password).then(() => {
        alert("Password copied!");
    });
}

// Delete password
function deletePassword(index) {
    let passwords = JSON.parse(localStorage.getItem('passwords')) || [];
    passwords.splice(index, 1);
    localStorage.setItem('passwords', JSON.stringify(passwords));
    loadPasswords();
}

// Close modal
function closeModal() {
    document.getElementById('newPasswordModal').classList.remove('active');
}

function togglePassword(index, realPassword) {
    const passwordSpan = document.getElementById(`password-${index}`);
    const buttonIcon = document.querySelector(`.password-item:nth-child(${index + 1}) .toggle-password i`);

    if (passwordSpan.textContent === "****") {
        passwordSpan.textContent = realPassword; // Show password
        buttonIcon.classList.replace("fa-eye", "fa-eye-slash");
    } else {
        passwordSpan.textContent = "****"; // Hide password
        buttonIcon.classList.replace("fa-eye-slash", "fa-eye");
    }
}

